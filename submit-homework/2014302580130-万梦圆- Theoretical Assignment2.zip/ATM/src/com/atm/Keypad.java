package com.atm;


import java.util.Scanner; // program uses Scanner to obtain user input


public  class Keypad
{
	//public static Scanner input;
private Scanner input; // reads data from the command line
//no-argument constructor initializes the Scanner
public boolean enter;
public int num;

// return an integer value entered by user
public int getInput() 
{

	 enter=false;
	 while(!enter){
		 System.out.print("");
		 }
 return num;
	
	
} // end method getInput
}