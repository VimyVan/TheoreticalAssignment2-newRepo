package com.atm;

public class ATMCaseStudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI gui=new GUI();
		gui.go();
		gui.theATM.run();
		
	}
}
