package com.atm;
import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.*;


public class GUI  {
	static ATM theATM=new ATM();
	static JFrame frame=new JFrame();
	static JTextArea output=new JTextArea(10,30);
	static JButton button0=new JButton("0");
	static JButton button1=new JButton("1");
	static JButton button2=new JButton("2");
	static JButton button3=new JButton("3");
	static JButton button4=new JButton("4");
	static JButton button5=new JButton("5");
	static JButton button6=new JButton("6");
	static JButton button7=new JButton("7");
	static JButton button8=new JButton("8");
	static JButton button9=new JButton("9");
	static JButton button10=new JButton("OK");


//��Ļ��ʾ
	public static void display(){
		output.setLineWrap(true);
		output.setEditable(false);
	}

	public void go(){
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panelbutt=new JPanel();
		JPanel panelcash=new JPanel();
		JPanel paneltext=new JPanel();
		
		//��ʾ����

		JScrollPane scroller=new JScrollPane(output);
		output.setLineWrap(true);
		output.setEditable(false);
	
		
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		paneltext.add(scroller);
		
		//��ť
		panelbutt.setSize(2,120);

		button0.addActionListener(new stringListener0());
		button1.addActionListener(new stringListener1());
		button2.addActionListener(new stringListener2());
		button3.addActionListener(new stringListener3());
		button4.addActionListener(new stringListener4());
		button5.addActionListener(new stringListener5());
		button6.addActionListener(new stringListener6());
		button7.addActionListener(new stringListener7());
		button8.addActionListener(new stringListener8());
		button9.addActionListener(new stringListener9());
		button10.addActionListener(new stringListener10());
		
		panelbutt.setLayout(new GridLayout(4,3));
		
		panelbutt.add(button1);
		panelbutt.add(button2);
		panelbutt.add(button3);
		panelbutt.add(button4);
		panelbutt.add(button5);
		panelbutt.add(button6);
		panelbutt.add(button7);
		panelbutt.add(button8);
		panelbutt.add(button9);
		panelbutt.add(button0);
		panelbutt.add(button10);
		
		
		
		//Ǯ�ۿ�
		JButton sendcash=new JButton("Insert deposit envelope here");
		JButton getcash=new JButton ("      Take cash here        ");
		panelcash.setLayout(new BoxLayout(panelcash,BoxLayout.Y_AXIS));
		panelcash.add(Box.createGlue());
		panelcash.add(getcash);
		panelcash.add(Box.createVerticalStrut (30));
		panelcash.add(sendcash);
		panelcash.add(Box.createGlue());

		
		frame.getContentPane().add(BorderLayout.NORTH,paneltext);
		frame.getContentPane().add(BorderLayout.EAST,panelcash);
		frame.getContentPane().add(BorderLayout.WEST,panelbutt);
		
		frame.setSize(400, 400);
		frame.setVisible(true);
		
		
	}
	
	static class stringListener1 implements ActionListener{
	
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"1";
			output.append("1");
		}
	}
	static class stringListener2 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"2";
			output.append("2");
		}
	}
	
	static class stringListener3 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"3";
			output.append("3");
		}
	}
	static class stringListener4 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"4";
			output.append("4");
		}
	}
	static class stringListener5 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"5";
			output.append("5");
		}
	}
	static class stringListener6 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"6";
			output.append("6");
		}
	}
	static class stringListener7 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"7";
			output.append("7");
		}
	}
	static class stringListener8 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"8";
			output.append("8");
		}
	}
	static class stringListener9 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"9";
			output.append("9");
		}
	}
	static class stringListener0 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ATM.inputnum=ATM.inputnum+"0";
			output.append("0");
		}
	}
	static class stringListener10 implements ActionListener{
		public void actionPerformed(ActionEvent event){
			theATM.keypad.num=Integer.parseInt(ATM.inputnum);
			theATM.keypad.enter=true;
			ATM.inputnum="";
			output.append(" ");
			
			
		}
	}	
}
